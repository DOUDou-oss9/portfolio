(async()=>{
 const page=figma.createPage();page.name='作品集首页 · 原生可编辑';await figma.setCurrentPageAsync(page);
 const available=await figma.listAvailableFontsAsync();
 const preferred=['Noto Sans SC','Noto Sans CJK SC','Microsoft YaHei','PingFang SC','Source Han Sans SC','Inter'];
 let regular;for(const family of preferred){regular=available.find(x=>x.fontName.family===family&&x.fontName.style==='Regular');if(regular)break}
 regular=(regular||available[0]).fontName;
 const bold=(available.find(x=>x.fontName.family===regular.family&&/Bold|Semibold|Heavy/.test(x.fontName.style))||{fontName:regular}).fontName;
 await figma.loadFontAsync(regular);await figma.loadFontAsync(bold);
 const C={paper:'#faf9f4',ink:'#22221f',yellow:'#f8ce46',blue:'#3153ce',green:'#b6dbc5',pink:'#e9b9ce',lavender:'#b8c8ee',grey:'#969891'};
 const rgb=h=>{h=h.replace('#','');return {r:parseInt(h.slice(0,2),16)/255,g:parseInt(h.slice(2,4),16)/255,b:parseInt(h.slice(4,6),16)/255}};
 const paint=h=>[{type:'SOLID',color:rgb(h)}];let native=0,reactions=0;const errors=[];
 function frame(parent,name,x,y,w,h,color){const f=figma.createFrame();f.name=name;f.x=x;f.y=y;f.resize(w,h);f.fills=color?paint(color):[];f.clipsContent=false;parent.appendChild(f);native++;return f}
 function box(parent,name,x,y,w,h,color,r=0,stroke){const n=figma.createRectangle();n.name=name;n.x=x;n.y=y;n.resize(w,h);n.fills=color?paint(color):[];if(r)n.cornerRadius=r;if(stroke){n.strokes=paint(stroke);n.strokeWeight=1}parent.appendChild(n);native++;return n}
 function text(parent,value,x,y,size=16,weight=false,color=C.ink,width){const n=figma.createText();n.name=value.slice(0,30);n.fontName=weight?bold:regular;n.characters=value;n.fontSize=size;n.lineHeight={unit:'PERCENT',value:155};n.fills=paint(color);parent.appendChild(n);if(width){n.textAutoResize='HEIGHT';n.resize(width,n.height)}n.x=x;n.y=y;native++;return n}
 function centerText(parent,value,y,size,weight=false,color=C.ink){const n=text(parent,value,0,y,size,weight,color);n.x=(parent.width-n.width)/2;return n}
 function star(parent,x,y,size,color,points=8){const n=figma.createStar();n.name='可编辑星形贴纸';n.pointCount=points;n.innerRadius=.45;n.resize(size,size);n.x=x;n.y=y;n.fills=paint(color);parent.appendChild(n);native++;return n}
 function shadow(node,opacity=.1,radius=12,y=5){node.effects=[{type:'DROP_SHADOW',color:{...rgb('#574b2b'),a:opacity},offset:{x:0,y},radius,spread:0,visible:true,blendMode:'NORMAL'}]}
 function chip(parent,label,x,y,w,color){box(parent,'技能贴纸 / '+label,x,y,w,32,color);text(parent,label,x+12,y+6,12)}
 const main=frame(page,'首页 / 纵向滚动 · 所有文字与图形可编辑',0,0,1440,1000,C.grey);main.clipsContent=true;main.overflowDirection='VERTICAL';
 const paper=frame(main,'整页纸张 / 3816px',100,28,1240,3760,C.paper);shadow(paper,.08,30,10);
 for(let y=32;y<3760;y+=32){const line=box(paper,'横线纸 / '+y,0,y,1240,1,'#eae9e3');line.opacity=.7}
 const anchors={};for(const [k,y] of [['home',70],['about',836],['works',1868],['contact',2892]])anchors[k]=box(paper,'导航定位 / '+k,0,y,1,1,null);
 const action=id=>({type:'NODE',destinationId:id,navigation:'SCROLL_TO',transition:{type:'SCROLL_ANIMATE',easing:{type:'EASE_IN_AND_OUT'},duration:.7}});
 async function connect(n,actions,trigger={type:'ON_CLICK'}){try{await n.setReactionsAsync([{trigger,actions}]);reactions++}catch(e){errors.push(n.name+': '+e.message)}}
 function hit(parent,name,x,y,w,h){const n=box(parent,name,x,y,w,h,'#ffffff');n.opacity=.001;return n}
 const hero=frame(paper,'01 / 首屏',0,70,1240,766);
 const label=box(hero,'姓名展示描边',259,115,720,160,null,0,'#ed946e');label.rotation=2;
 centerText(hero,'你好，很高兴你翻开这一页',87,12);
 centerText(hero,'PORTFOLIO',127,96,true);
 star(hero,955,98,60,'#83ab46');
 centerText(hero,'● 青岛 · 视觉传达设计在读',300,11);
 centerText(hero,'用图形讲故事，',355,44,true);centerText(hero,'让想法被看见。',420,44,true);
 centerText(hero,'品牌设计 / 包装设计 / 平面视觉 / 其他设计',500,13,false,'#696963');
 const start=box(hero,'查看作品集按钮',523,556,194,46,C.ink);text(hero,'翻开我的作品集 ↓',548,569,13,false,'#ffffff');await connect(hit(hero,'点击 / 平滑滚动到作品',523,556,194,46),[action(anchors.works.id)]);
 const note1=frame(hero,'黄色便签',95,205,185,34,C.yellow);note1.rotation=7;text(note1,'视觉传达 · 灵感不设限',12,8,12,true);
 const note2=frame(hero,'绿色便签',980,285,178,35,C.green);note2.rotation=-6;text(note2,'保持好奇，认真设计。',12,8,12,true);
 centerText(hero,'每个想法，都值得落在纸上 ↗',641,12,false,'#77776e');
 function heading(section,number,title){box(section,'分割线',64,0,1112,1,'#c9c7bd');text(section,number,64,26,12);text(section,title,64,56,34,true)}
 const about=frame(paper,'02 / 关于我',0,836,1240,1032);heading(about,'01 / 关于我的几张便签','设计之外，也是我。');
 const note=box(about,'空白绿色个人便签',72,157,280,365,'#e8eddf');note.rotation=3;shadow(note,.1,0,7);const tape=box(about,'蓝色胶带',157,145,100,25,C.lavender);tape.opacity=.65;tape.rotation=-1;
 text(about,'你好，我是一个喜欢琢磨细节的人。',428,175,24,true);
 text(about,'我关注图形、字体与版式之间的关系，也喜欢探索品牌故事如何延伸到包装、海报和数字界面。',428,239,14,false,C.ink,715);
 text(about,'在平面设计与新媒体运营实习中，我参与宣传物料、图文内容和短视频制作，积累了面向实际使用场景的设计经验。',428,309,14,false,C.ink,715);
 ['品牌VI','印刷排版','商业插画','新媒体视觉'].forEach((s,i)=>chip(about,s,428+i*110,392,101,[C.yellow,C.green,C.pink,C.lavender][i]));
 text(about,'我的工具箱',428,451,18,true);text(about,'Photoshop / Illustrator / InDesign / Figma\nMidjourney / Stable Diffusion',428,496,14);
 chip(about,'我的设计方式',64,619,139,'#e5ebda');text(about,'让灵感，一步步落地。',920,621,19,true);
 const processes=[['01 / 发现','先理解，再动笔','从主题、受众和使用场景出发，梳理信息，找到值得表达的核心。','观察 / 收集 / 提炼','#ece4d2'],['02 / 探索','给想法一个形状','尝试图形、字体与配色，在不同的版式里寻找清晰而有个性的表达。','构思 / 配色 / 排版','#e0eadf'],['03 / 打磨','让细节回应场景','关注阅读层级与实际应用，让视觉从一张画面延展为完整的设计。','调整 / 延展 / 呈现','#e1e7f1']];
 processes.forEach((p,i)=>{const card=frame(about,'设计方式 / '+p[1],64+i*378,684,356,245,p[4]);box(card,'顶边',0,0,356,3,['#c9b891','#abc2a6','#adbdd5'][i]);text(card,p[0],22,25,11);text(card,p[1],22,62,21,true);text(card,p[2],22,111,13,false,C.ink,312);box(card,'分隔线',22,195,312,1,'#bcb9af');text(card,p[3],22,210,10)});
 const works=frame(paper,'03 / 作品合集（仅首页封面）',0,1868,1240,1024);heading(works,'02 / 我的作品档案','想法，在这里成形。');chip(works,'从一笔灵感，到完整表达。',956,65,220,C.yellow);
 const library=frame(page,'首页悬停组件 / 可编辑变体',1700,0,1500,2300);let componentY=0;
 async function folder(x,y,w,h,index,title,desc,count,palette,sticker,caption){
  const variants=[];
  for(const state of ['Default','Hover','Selected']){
   const c=figma.createComponent();c.name='State='+state;c.resize(w,h);c.fills=[];c.clipsContent=false;library.appendChild(c);
   const lift=state==='Hover'?-7:0;
   const back=box(c,'后层白纸',45,20+lift,w-95,180,'#faf8ef',0,'#d9d3c4');back.rotation=6;
   const edge=box(c,'作品露出边角 / 图形占位',55,27+lift,w-108,160,'#d7dccc');edge.rotation=4;
   const stickerFrame=frame(c,'拼贴贴纸 / '+sticker,28,9+lift,w-44,205,['#f0e8d8','#dbe5d3','#ecd5d8','#d4dff0'][index]);stickerFrame.rotation=index%2?-3:3;shadow(stickerFrame,.08,5,2);
   text(stickerFrame,'设计剪贴簿 / 0'+(index+1),20,22,9);text(stickerFrame,sticker,20,53,28);star(stickerFrame,w-135,58,45,['#3651a1','#577855','#a84a68','#3651a1'][index]);text(stickerFrame,caption,20,104,10);const tape=box(stickerFrame,'装饰胶带',w/2-61,-11,66,22,index%2?C.lavender:'#eacb72');tape.opacity=.65;tape.rotation=-7;
   box(c,'文件夹页签',0,h-185+lift,w*.43,22,palette,4);
   const cover=box(c,'文件夹封面',0,h-165+lift,w,165,palette,5);shadow(cover,.07,12,6);
   text(c,'设计档案 / 0'+(index+1),24,h-143+lift,10);text(c,title,24,h-114+lift,29,true);text(c,desc,24,h-63+lift,12);text(c,count+' · '+(state==='Selected'?'已选择分类':'设计分类'),24,h-30+lift,10,false,'#686153');
   text(c,state==='Hover'?'↗':'↗',w-43,h-105+lift,state==='Hover'?27:22);
   const clip=box(c,'回形针外环',w-32,h-179+lift,13,39,null,7,'#78684e');clip.rotation=-24;const inner=box(c,'回形针内环',w-29,h-175+lift,7,30,null,5,'#78684e');inner.rotation=-24;
   if(state==='Selected'){const selection=box(c,'选中轮廓',-4,h-169,w+8,173,null,6,C.blue);selection.strokeWeight=2}
   variants.push(c);
  }
  const set=figma.combineAsVariants(variants,library);set.name=title+' / 可编辑交互组件';set.x=10;set.y=componentY;componentY+=h+70;
  const change=id=>({type:'NODE',destinationId:id,navigation:'CHANGE_TO',transition:{type:'SMART_ANIMATE',easing:{type:'EASE_OUT'},duration:.24}});
  for(let i=0;i<3;i++){
   const rs=[{trigger:{type:'ON_CLICK'},actions:[change(variants[i===2?0:2].id)]}];
   if(i<2)rs.push({trigger:{type:i===0?'MOUSE_ENTER':'MOUSE_LEAVE',delay:0,deprecatedVersion:false},actions:[change(variants[i===0?1:0].id)]});
   try{await variants[i].setReactionsAsync(rs);reactions+=rs.length}catch(e){errors.push(title+e.message)}
  }
  const instance=variants[0].createInstance();instance.name=title+' / 点击与悬停';instance.x=x;instance.y=y;works.appendChild(instance);
 }
 const folders=[['品牌设计','山海故事，成为品牌的独特印记。','1 个项目','#e9d9bb','品牌灵感','山海 / 图形 / 故事'],['包装设计','让品牌的心意，有形可触。','1 个项目','#d6c29e','包装手记','自然 / 纸张 / 温度'],['平面设计','图形、文字与色彩的日常对话。','4 个项目','#99c2d7','平面实验','字体 / 色彩 / 编排'],['其他设计','不设边界，收集更多设计可能。','1 个项目','#b6cde4','创意收集','探索 / 想象 / 可能']];
 for(let i=0;i<4;i++){const p=folders[i];await folder(100+i%2*535,166+Math.floor(i/2)*368,487,310,i,...p)}
 const contact=frame(paper,'04 / 联系方式',0,2892,1240,805,'#faf9f4');for(let y=31;y<805;y+=32)box(contact,'横线纸',0,y,1240,1,'#e9e7df');chip(contact,'// 联系方式 //',40,55,134,C.yellow);text(contact,'打个招呼！',40,97,57,true);text(contact,'关于设计机会、项目合作，或是一个新鲜的想法，\n欢迎联系我，一起让灵感发生。',790,84,14,false,'#53534c',410);
 function contactCard(name,title,desc,value,x,y,w,h,bg,href){const f=frame(contact,name,x,y,w,h,'#e8e1db');f.cornerRadius=8;const inner=box(f,'内卡片',8,8,w-16,h-57,bg,5,'#d2cec2');text(f,title,24,32,17,true);text(f,desc,24,75,13,false,'#53534c',w-48);text(f,value,20,h-35,14,true);return {f,href}}
 const mail=contactCard('邮箱联系卡片','一起聊聊设计','关于作品、合作或工作机会，\n期待收到你的来信。','1139637692@qq.com →',40,219,270,225,'#f9f7ee','mailto:1139637692@qq.com');
 const wechat=contactCard('微信联系卡片','微信联系','添加微信，\n让沟通更直接一点。','DunDHupoy',324,219,270,225,C.lavender,null);
 const phone=contactCard('手机联系卡片','也可以，直接打给我','有想进一步交流的事情？欢迎电话联系。','18053294457 →',40,458,554,184,'#f9f7ee','tel:18053294457');
 for(const card of [mail,phone])await connect(hit(card.f,'点击 / 外部联系',0,0,card.f.width,card.f.height),[{type:'URL',url:card.href}]);
 const form=frame(contact,'留言卡片 / 每一项文字均可编辑',626,219,574,423,C.yellow);form.cornerRadius=15;shadow(form,.09,24,9);const formTape=box(form,'白色胶带',453,-11,90,27,'#ffffff');formTape.rotation=-8;formTape.opacity=.65;
 text(form,'称呼',30,30,13,true);text(form,'邮箱',300,30,13,true);box(form,'称呼输入框',30,62,244,52,'#fff8d9',5);box(form,'邮箱输入框',300,62,244,52,'#fff8d9',5);text(form,'怎么称呼你？',45,77,14,false,'#66604c');text(form,'你的邮箱地址',315,77,14,false,'#66604c');text(form,'留言',30,132,13,true);box(form,'留言输入框',30,163,514,153,'#fff8d9',5);text(form,'聊聊你的想法吧……',45,179,14,false,'#66604c');text(form,'填写后将打开邮件应用，由你确认发送。',30,342,10,false,'#514722',250);box(form,'发送按钮',397,337,147,47,C.ink,5);text(form,'发送邮件 ↗',416,349,14,true,'#fff8da');await connect(hit(form,'点击 / 打开邮件',397,337,147,47),[{type:'URL',url:'mailto:1139637692@qq.com'}]);
 text(paper,'李诺谣 © 2026 · 用图形讲故事，让想法被看见。',40,3717,11);text(paper,'回到顶部 ↑',1110,3717,11);await connect(hit(paper,'点击 / 回到顶部',1096,3710,110,35),[action(anchors.home.id)]);
 const header=frame(main,'固定导航 / 原生文字',100,28,1240,70,C.paper);box(header,'下边线',0,69,1240,1,'#dddcd4');star(header,31,23,20,C.blue);await connect(hit(header,'点击 / 标识回首页',22,13,40,45),[action(anchors.home.id)]);
 for(const [label,key,x,w] of [['首页','home',840,55],['关于我','about',915,65],['作品集','works',997,65],['联系我 ↗','contact',1090,119]]){text(header,label,x+8,23,13,true);if(key==='contact')box(header,'联系按钮描边',x,17,w,37,null,0,C.ink);await connect(hit(header,'导航 / '+label,x,15,w,42),[action(anchors[key].id)])}
 main.numberOfFixedChildren=1;page.flowStartingPoints=[{nodeId:main.id,name:'首页 / 原生可编辑 · 滚动与悬停'}];page.selection=[main];figma.viewport.scrollAndZoomIntoView([main]);
 console.log('原生图层 '+native+'，交互 '+reactions,errors);figma.notify(errors.length?'首页已生成，有'+errors.length+'个交互需检查':'已生成原生可编辑首页。选中首页，点击演示，可滚动、导航定位与悬停。',{timeout:12000});figma.closePlugin();
})().catch(e=>{console.error(e);figma.notify('生成失败：'+e.message,{error:true,timeout:15000});figma.closePlugin()});
