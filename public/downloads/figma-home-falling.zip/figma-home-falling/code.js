(async()=>{
 const page=figma.createPage();page.name='作品集首页 · 原生可编辑';await figma.setCurrentPageAsync(page);
 const available=await figma.listAvailableFontsAsync();
 const preferred=['Noto Sans SC','Noto Sans CJK SC','Microsoft YaHei','PingFang SC','Source Han Sans SC','Inter'];
 let regular;for(const family of preferred){regular=available.find(x=>x.fontName.family===family&&x.fontName.style==='Regular');if(regular)break}
 regular=(regular||available[0]).fontName;
 const bold=(available.find(x=>x.fontName.family===regular.family&&/Bold|Semibold|Heavy/.test(x.fontName.style))||{fontName:regular}).fontName;
 await figma.loadFontAsync(regular);await figma.loadFontAsync(bold);
 const C={paper:'#faf9f4',ink:'#22221f',yellow:'#f8ce46',blue:'#3153ce',green:'#b6dbc5',pink:'#e9b9ce',lavender:'#b8c8ee',grey:'#969891'};
 const rgb=h=>{h=h.replace('#','');return {r:parseInt(h.slice(0,2),16)/255,g:parseInt(h.slice(2,4),16)/255,b:parseInt(h.slice(4,6),16)/255}};
 const paint=h=>[{type:'SOLID',color:rgb(h)}];let native=0,reactions=0;const errors=[];
 function frame(parent,name,x,y,w,h,color){const f=figma.createFrame();f.name=name;f.x=x;f.y=y;f.resize(w,h);f.fills=color?paint(color):[];f.clipsContent=false;parent.appendChild(f);native++;return f}
 function box(parent,name,x,y,w,h,color,r=0,stroke){const n=figma.createRectangle();n.name=name;n.x=x;n.y=y;n.resize(w,h);n.fills=color?paint(color):[];if(r)n.cornerRadius=r;if(stroke){n.strokes=paint(stroke);n.strokeWeight=1}parent.appendChild(n);native++;return n}
 function text(parent,value,x,y,size=16,weight=false,color=C.ink,width){const n=figma.createText();n.name=value.slice(0,30);n.fontName=weight?bold:regular;n.characters=value;n.fontSize=size;n.lineHeight={unit:'PERCENT',value:155};n.fills=paint(color);parent.appendChild(n);if(width){n.textAutoResize='HEIGHT';n.resize(width,n.height)}n.x=x;n.y=y;native++;return n}
 function centerText(parent,value,y,size,weight=false,color=C.ink){const n=text(parent,value,0,y,size,weight,color);n.x=(parent.width-n.width)/2;return n}
 function star(parent,x,y,size,color,points=8){const n=figma.createStar();n.name='可编辑星形贴纸';n.pointCount=points;n.innerRadius=.45;n.resize(size,size);n.x=x;n.y=y;n.fills=paint(color);parent.appendChild(n);native++;return n}
 function shadow(node,opacity=.1,radius=12,y=5){node.effects=[{type:'DROP_SHADOW',color:{...rgb('#574b2b'),a:opacity},offset:{x:0,y},radius,spread:0,visible:true,blendMode:'NORMAL'}]}
 function chip(parent,label,x,y,w,color){box(parent,'技能贴纸 / '+label,x,y,w,32,color);text(parent,label,x+12,y+6,12)}
 const main=frame(page,'首页 / 纵向滚动 · 所有文字与图形可编辑',0,0,1440,1000,C.grey);main.clipsContent=true;main.overflowDirection='VERTICAL';
 const paper=frame(main,'整页纸张 / 3816px',100,28,1240,3760,C.paper);shadow(paper,.08,30,10);
 for(let y=32;y<3760;y+=32){const line=box(paper,'横线纸 / '+y,0,y,1240,1,'#eae9e3');line.opacity=.7}
 const anchors={};for(const [k,y] of [['home',70],['about',836],['works',1868],['contact',2892]])anchors[k]=box(paper,'导航定位 / '+k,0,y,1,1,null);
 const action=id=>({type:'NODE',destinationId:id,navigation:'SCROLL_TO',transition:{type:'SCROLL_ANIMATE',easing:{type:'EASE_IN_AND_OUT'},duration:.7}});
 async function connect(n,actions,trigger={type:'ON_CLICK'}){try{await n.setReactionsAsync([{trigger,actions}]);reactions++}catch(e){errors.push(n.name+': '+e.message)}}
 function hit(parent,name,x,y,w,h){const n=box(parent,name,x,y,w,h,'#ffffff');n.opacity=.001;return n}
 const hero=frame(paper,'01 / 首屏',0,70,1240,766);
 const label=box(hero,'姓名展示描边',259,115,720,160,null,0,'#ed946e');label.rotation=2;
 centerText(hero,'你好，很高兴你翻开这一页',87,12);
 centerText(hero,'PORTFOLIO',127,96,true);
 star(hero,955,98,60,'#83ab46');
 centerText(hero,'● 青岛 · 视觉传达设计在读',300,11);
 centerText(hero,'用图形讲故事，',355,44,true);centerText(hero,'让想法被看见。',420,44,true);
 centerText(hero,'品牌设计 / 包装设计 / 平面视觉 / 其他设计',500,13,false,'#696963');
 const start=box(hero,'查看作品集按钮',523,556,194,46,C.ink);text(hero,'翻开我的作品集 ↓',548,569,13,false,'#ffffff');await connect(hit(hero,'点击 / 平滑滚动到作品',523,556,194,46),[action(anchors.works.id)]);
 const note1=frame(hero,'黄色便签',95,205,185,34,C.yellow);note1.rotation=7;text(note1,'视觉传达 · 灵感不设限',12,8,12,true);
 const note2=frame(hero,'绿色便签',980,285,178,35,C.green);note2.rotation=-6;text(note2,'保持好奇，认真设计。',12,8,12,true);
 centerText(hero,'每个想法，都值得落在纸上 ↗',641,12,false,'#77776e');
 function heading(section,number,title){box(section,'分割线',64,0,1112,1,'#c9c7bd');text(section,number,64,26,12);text(section,title,64,56,34,true)}
 const about=frame(paper,'02 / 关于我',0,836,1240,1032);heading(about,'01 / 关于我的几张便签','设计之外，也是我。');
 const note=box(about,'空白绿色个人便签',72,157,280,365,'#e8eddf');note.rotation=3;shadow(note,.1,0,7);const tape=box(about,'蓝色胶带',157,145,100,25,C.lavender);tape.opacity=.65;tape.rotation=-1;
 text(about,'你好，我是一个喜欢琢磨细节的人。',428,175,24,true);
 text(about,'我关注图形、字体与版式之间的关系，也喜欢探索品牌故事如何延伸到包装、海报和数字界面。',428,239,14,false,C.ink,715);
 text(about,'在平面设计与新媒体运营实习中，我参与宣传物料、图文内容和短视频制作，积累了面向实际使用场景的设计经验。',428,309,14,false,C.ink,715);
 ['品牌VI','印刷排版','商业插画','新媒体视觉'].forEach((s,i)=>chip(about,s,428+i*110,392,101,[C.yellow,C.green,C.pink,C.lavender][i]));
 text(about,'我的工具箱',428,451,18,true);text(about,'Photoshop / Illustrator / InDesign / Figma\nMidjourney / Stable Diffusion',428,496,14);
 chip(about,'我的设计方式',64,619,139,'#e5ebda');text(about,'让灵感，一步步落地。',920,621,19,true);
 const processes=[['01 / 发现','先理解，再动笔','从主题、受众和使用场景出发，梳理信息，找到值得表达的核心。','观察 / 收集 / 提炼','#ece4d2'],['02 / 探索','给想法一个形状','尝试图形、字体与配色，在不同的版式里寻找清晰而有个性的表达。','构思 / 配色 / 排版','#e0eadf'],['03 / 打磨','让细节回应场景','关注阅读层级与实际应用，让视觉从一张画面延展为完整的设计。','调整 / 延展 / 呈现','#e1e7f1']];
 processes.forEach((p,i)=>{const card=frame(about,'设计方式 / '+p[1],64+i*378,684,356,245,p[4]);box(card,'顶边',0,0,356,3,['#c9b891','#abc2a6','#adbdd5'][i]);text(card,p[0],22,25,11);text(card,p[1],22,62,21,true);text(card,p[2],22,111,13,false,C.ink,312);box(card,'分隔线',22,195,312,1,'#bcb9af');text(card,p[3],22,210,10)});
 const works=frame(paper,'03 / 作品合集（仅首页封面）',0,1868,1240,1024);heading(works,'02 / 我的作品档案','想法，在这里成形。');chip(works,'从一笔灵感，到完整表达。',956,65,220,C.yellow);
 const library=frame(page,'首页悬停组件 / 可编辑变体',1700,0,1500,2300);let componentY=0;
 async function folder(x,y,w,h,index,title,desc,count,palette,sticker,caption){
  const variants=[];
  for(const state of ['Default','Hover','Selected']){
   const c=figma.createComponent();c.name='State='+state;c.resize(w,h);c.fills=[];c.clipsContent=false;library.appendChild(c);
   const lift=state==='Hover'?-7:0;
   const back=box(c,'后层白纸',45,20+lift,w-95,180,'#faf8ef',0,'#d9d3c4');back.rotation=6;
   const edge=box(c,'作品露出边角 / 图形占位',55,27+lift,w-108,160,'#d7dccc');edge.rotation=4;
   const stickerFrame=frame(c,'拼贴贴纸 / '+sticker,28,9+lift,w-44,205,['#f0e8d8','#dbe5d3','#ecd5d8','#d4dff0'][index]);stickerFrame.rotation=index%2?-3:3;shadow(stickerFrame,.08,5,2);
   text(stickerFrame,'设计剪贴簿 / 0'+(index+1),20,22,9);text(stickerFrame,sticker,20,53,28);star(stickerFrame,w-135,58,45,['#3651a1','#577855','#a84a68','#3651a1'][index]);text(stickerFrame,caption,20,104,10);const tape=box(stickerFrame,'装饰胶带',w/2-61,-11,66,22,index%2?C.lavender:'#eacb72');tape.opacity=.65;tape.rotation=-7;
   box(c,'文件夹页签',0,h-185+lift,w*.43,22,palette,4);
   const cover=box(c,'文件夹封面',0,h-165+lift,w,165,palette,5);shadow(cover,.07,12,6);
   text(c,'设计档案 / 0'+(index+1),24,h-143+lift,10);text(c,title,24,h-114+lift,29,true);text(c,desc,24,h-63+lift,12);text(c,count+' · '+(state==='Selected'?'已选择分类':'设计分类'),24,h-30+lift,10,false,'#686153');
   text(c,state==='Hover'?'↗':'↗',w-43,h-105+lift,state==='Hover'?27:22);
   const clip=box(c,'回形针外环',w-32,h-179+lift,13,39,null,7,'#78684e');clip.rotation=-24;const inner=box(c,'回形针内环',w-29,h-175+lift,7,30,null,5,'#78684e');inner.rotation=-24;
   if(state==='Selected'){const selection=box(c,'选中轮廓',-4,h-169,w+8,173,null,6,C.blue);selection.strokeWeight=2}
   variants.push(c);
  }
  const set=figma.combineAsVariants(variants,library);set.name=title+' / 可编辑交互组件';set.x=10;set.y=componentY;componentY+=h+70;
  const change=id=>({type:'NODE',destinationId:id,navigation:'CHANGE_TO',transition:{type:'SMART_ANIMATE',easing:{type:'EASE_OUT'},duration:.24}});
  for(let i=0;i<3;i++){
   const rs=[{trigger:{type:'ON_CLICK'},actions:[change(variants[i===2?0:2].id)]}];
   if(i<2)rs.push({trigger:{type:i===0?'MOUSE_ENTER':'MOUSE_LEAVE',delay:0,deprecatedVersion:false},actions:[change(variants[i===0?1:0].id)]});
   try{await variants[i].setReactionsAsync(rs);reactions+=rs.length}catch(e){errors.push(title+e.message)}
  }
  const instance=variants[0].createInstance();instance.name=title+' / 点击与悬停';instance.x=x;instance.y=y;works.appendChild(instance);
 }
 const folders=[['品牌设计','山海故事，成为品牌的独特印记。','1 个项目','#e9d9bb','品牌灵感','山海 / 图形 / 故事'],['包装设计','让品牌的心意，有形可触。','1 个项目','#d6c29e','包装手记','自然 / 纸张 / 温度'],['平面设计','图形、文字与色彩的日常对话。','4 个项目','#99c2d7','平面实验','字体 / 色彩 / 编排'],['其他设计','不设边界，收集更多设计可能。','1 个项目','#b6cde4','创意收集','探索 / 想象 / 可能']];
 for(let i=0;i<4;i++){const p=folders[i];await folder(100+i%2*535,166+Math.floor(i/2)*368,487,310,i,...p)}
 const contact=frame(paper,'04 / 联系方式',0,2892,1240,805,'#faf9f4');for(let y=31;y<805;y+=32)box(contact,'横线纸',0,y,1240,1,'#e9e7df');chip(contact,'// 联系方式 //',40,55,134,C.yellow);text(contact,'打个招呼！',40,97,57,true);text(contact,'关于设计机会、项目合作，或是一个新鲜的想法，\n欢迎联系我，一起让灵感发生。',790,84,14,false,'#53534c',410);
 function contactCard(name,title,desc,value,x,y,w,h,bg,href){const f=frame(contact,name,x,y,w,h,'#e8e1db');f.cornerRadius=8;const inner=box(f,'内卡片',8,8,w-16,h-57,bg,5,'#d2cec2');text(f,title,24,32,17,true);text(f,desc,24,75,13,false,'#53534c',w-48);text(f,value,20,h-35,14,true);return {f,href}}
 const mail=contactCard('邮箱联系卡片','一起聊聊设计','关于作品、合作或工作机会，\n期待收到你的来信。','1139637692@qq.com →',40,219,270,225,'#f9f7ee','mailto:1139637692@qq.com');
 const wechat=contactCard('微信联系卡片','微信联系','添加微信，\n让沟通更直接一点。','DunDHupoy',324,219,270,225,C.lavender,null);
 const phone=contactCard('手机联系卡片','也可以，直接打给我','有想进一步交流的事情？欢迎电话联系。','18053294457 →',40,458,554,184,'#f9f7ee','tel:18053294457');
 for(const card of [mail,phone])await connect(hit(card.f,'点击 / 外部联系',0,0,card.f.width,card.f.height),[{type:'URL',url:card.href}]);
 const form=frame(contact,'留言卡片 / 每一项文字均可编辑',626,219,574,423,C.yellow);form.cornerRadius=15;shadow(form,.09,24,9);const formTape=box(form,'白色胶带',453,-11,90,27,'#ffffff');formTape.rotation=-8;formTape.opacity=.65;
 text(form,'称呼',30,30,13,true);text(form,'邮箱',300,30,13,true);box(form,'称呼输入框',30,62,244,52,'#fff8d9',5);box(form,'邮箱输入框',300,62,244,52,'#fff8d9',5);text(form,'怎么称呼你？',45,77,14,false,'#66604c');text(form,'你的邮箱地址',315,77,14,false,'#66604c');text(form,'留言',30,132,13,true);box(form,'留言输入框',30,163,514,153,'#fff8d9',5);text(form,'聊聊你的想法吧……',45,179,14,false,'#66604c');text(form,'填写后将打开邮件应用，由你确认发送。',30,342,10,false,'#514722',250);box(form,'发送按钮',397,337,147,47,C.ink,5);text(form,'发送邮件 ↗',416,349,14,true,'#fff8da');await connect(hit(form,'点击 / 打开邮件',397,337,147,47),[{type:'URL',url:'mailto:1139637692@qq.com'}]);
 text(paper,'李诺谣 © 2026 · 用图形讲故事，让想法被看见。',40,3717,11);text(paper,'回到顶部 ↑',1110,3717,11);await connect(hit(paper,'点击 / 回到顶部',1096,3710,110,35),[action(anchors.home.id)]);
 const header=frame(main,'固定导航 / 原生文字',100,28,1240,70,C.paper);box(header,'下边线',0,69,1240,1,'#dddcd4');star(header,31,23,20,C.blue);await connect(hit(header,'点击 / 标识回首页',22,13,40,45),[action(anchors.home.id)]);
 for(const [label,key,x,w] of [['首页','home',840,55],['关于我','about',915,65],['作品集','works',997,65],['联系我 ↗','contact',1090,119]]){text(header,label,x+8,23,13,true);if(key==='contact')box(header,'联系按钮描边',x,17,w,37,null,0,C.ink);await connect(hit(header,'导航 / '+label,x,15,w,42),[action(anchors[key].id)])}
 main.numberOfFixedChildren=1;
 // Separate full-length design canvas from the clipped prototype viewport.
 const overviewPage=figma.createPage();overviewPage.name='01 · 完整首页长图（所有内容可见可编辑）';
 const overview=main.clone();overviewPage.appendChild(overview);overview.name='完整首页 / 1440 × 3816 / 编辑此长图';overview.x=0;overview.y=0;overview.resize(1440,3816);overview.clipsContent=false;overview.overflowDirection='NONE';overview.numberOfFixedChildren=0;
 main.name='首页演示 / 1000px窗口 · 可下拉浏览';page.name='02 · 加载与首页交互演示';
 const loadingFrames=[];
 for(let phase=0;phase<3;phase++){
  const load=frame(page,'加载页 / '+(phase+1)+'秒 · 原生可编辑',-1700,phase*1150,1440,1000,C.grey);load.clipsContent=true;
  for(let x=0;x<1440;x+=48){const n=box(load,'背景网格竖线',x,0,1,1000,'#ffffff');n.opacity=.23}
  for(let y=0;y<1000;y+=48){const n=box(load,'背景网格横线',0,y,1440,1,'#ffffff');n.opacity=.23}
  const sheet=frame(load,'纸张',435,200,570,600,C.paper);sheet.rotation=1;shadow(sheet,.09,0,10);
  for(let y=32;y<600;y+=32){const n=box(sheet,'横线纸 / '+y,0,y,570,1,'#eae9e3');n.opacity=.7}
  const tape=box(sheet,'蓝色胶带',225,-13,120,32,C.lavender);tape.opacity=.7;tape.rotation=-3;
  text(sheet,'李诺谣 / 设计档案',38,30,10,false,'#78786c');text(sheet,'第一章',485,30,10,false,'#78786c');box(sheet,'顶部细线',38,62,494,1,'#d7d5ca');
  const art=frame(sheet,'文件夹插画 / 所有图形可编辑',150,93,270,220);
  const white=box(art,'白色便笺',30,30+(phase===1?-6:0),205,150,'#faf8ef',0,'#d8d4c6');white.rotation=12;shadow(white,.07,6,2);
  const green=box(art,'绿色便笺',42,23+(phase===1?-8:0),205,150,'#b9d4c1');green.rotation=-8;shadow(green,.07,6,2);
  box(art,'文件夹页签',9,62,115,22,'#e8d4ae',3);const front=box(art,'文件夹正面',9,81,252,135,'#e8d4ae',4);shadow(front,.07,8,4);
  text(art,'灵感 · 细节 · 表达',31,102,9,false,'#605b50');text(art,'PORTFOLIO',31,136,26,true);star(art,213,170,31,'#83ab46');
  centerText(sheet,'每个想法，都值得落在纸上。',330,11,false,'#77756b');centerText(sheet,'正在翻开作品集…',360,24,true);
  box(sheet,'进度轨道',145,420,280,4,'#e3e0d4');const track=frame(sheet,'进度条裁切',145,420,280,4);track.clipsContent=true;box(track,'动态进度条',[-100,85,240][phase],0,112,4,C.blue);
  centerText(sheet,'正在准备页面与作品图片',441,10,false,'#77756b');const skip=centerText(sheet,'直接进入 ↗',484,11);box(sheet,'直接进入下划线',246,507,78,1,'#88887d');
  await connect(hit(sheet,'点击 / 直接进入首页',236,477,100,40),[{type:'NODE',destinationId:main.id,navigation:'NAVIGATE',transition:{type:'DISSOLVE',easing:{type:'EASE_OUT'},duration:.25},resetScrollPosition:true}]);
  box(sheet,'底部细线',38,540,494,1,'#d7d5ca');text(sheet,'保持好奇，认真设计。',38,558,10,false,'#78786c');star(sheet,518,558,16,C.blue,4);
  loadingFrames.push(load);
 }
 for(let i=0;i<3;i++){
  await connect(loadingFrames[i],[{type:'NODE',destinationId:(i<2?loadingFrames[i+1]:main).id,navigation:'NAVIGATE',transition:{type:i<2?'SMART_ANIMATE':'DISSOLVE',easing:{type:'EASE_IN_AND_OUT'},duration:i<2?.7:.25},resetScrollPosition:true}],{type:'AFTER_TIMEOUT',timeout:i<2?.3:1});
 }
 // A separate editable loading design on the overview page, next to the full homepage.
 const loadingDesign=loadingFrames[0].clone();overviewPage.appendChild(loadingDesign);loadingDesign.name='加载页设计 / 原生文字与图形可编辑';loadingDesign.x=-1600;loadingDesign.y=0;
 page.flowStartingPoints=[{nodeId:loadingFrames[0].id,name:'从加载页开始 / 三秒进入'},{nodeId:main.id,name:'直接演示首页 / 下拉滚动'}];
 overviewPage.flowStartingPoints=[];
 await figma.setCurrentPageAsync(overviewPage);overviewPage.selection=[overview];figma.viewport.scrollAndZoomIntoView([overview]);
  // Four native, editable category landing-page templates, without real projects.
 const categoryPages=[];
 const navTo=(id,type='DISSOLVE')=>({type:'NODE',destinationId:id,navigation:'NAVIGATE',transition:{type,easing:{type:'EASE_OUT'},duration:.3},resetScrollPosition:true});
 function find(node,predicate){if(predicate(node))return node;for(const child of node.children||[]){const found=find(child,predicate);if(found)return found}return null}
 const entryPages={};
 for(const target of ['works','contact']){
  const entry=main.clone();page.appendChild(entry);entry.name='首页定位 / '+target;entry.x=3400;entry.y=target==='works'?0:1150;
  const anchor=find(entry,n=>n.name==='导航定位 / '+target);
  await connect(entry,[action(anchor.id)],{type:'AFTER_TIMEOUT',timeout:.05});entryPages[target]=entry;
 }
 for(let i=0;i<4;i++){
  const info=folders[i],cat=frame(page,info[0]+' / 空白案例模板',5100+i*1600,0,1440,1000,C.grey);cat.clipsContent=true;cat.overflowDirection='VERTICAL';
  const sheet=frame(cat,'案例模板长页 / 所有内容可编辑',100,28,1240,1670,C.paper);
  for(let y=32;y<1670;y+=32)box(sheet,'横线纸',0,y,1240,1,'#eae9e3');
  text(sheet,'← 返回作品合集',54,25,14,true);await connect(hit(sheet,'点击 / 返回作品合集',44,18,180,42),[navTo(entryPages.works.id)]);
  text(sheet,'关于我',1004,25,13,true);await connect(hit(sheet,'点击 / 回到首页',995,18,90,42),[navTo(main.id)]);
  text(sheet,'联系我 ↗',1100,25,13,true);await connect(hit(sheet,'点击 / 联系我',1091,18,105,42),[navTo(entryPages.contact.id)]);
  box(sheet,'头部分隔线',40,76,1160,1,'#c9c7bd');
  chip(sheet,'设计档案 / 0'+(i+1),54,125,155,info[3]);text(sheet,info[0],54,180,62,true);text(sheet,info[1],58,282,18);
  const note=frame(sheet,'模板说明便签',804,153,365,120,['#e8eddf','#f0e8d8','#ecd5d8','#d4dff0'][i]);note.rotation=-4;shadow(note,.08,8,4);text(note,'把下一个好想法，贴在这里。',22,26,20,true);text(note,'这是可编辑的案例模板，暂无实际作品。',22,73,12);const tape=box(note,'胶带',140,-10,80,23,C.lavender);tape.opacity=.6;
  text(sheet,'项目档案 / 待填充',54,405,13);text(sheet,'让你的项目，在这里展开。',54,445,30,true);
  for(let j=0;j<3;j++){
   const card=frame(sheet,'项目占位卡 / '+(j+1),54+j*387,530,358,455,'#eee8db');shadow(card,.06,10,4);
   const cover=box(card,'封面占位 / 可替换矢量图形',12,12,334,249,['#e3eadb','#dbe3f0','#efdbdf'][(i+j)%3],3);
   box(card,'拼贴纸张',65,57,220,135,'#faf8ed',0,'#d5cfbf');star(card,145,95,62,['#6c8e5d',C.blue,'#af647c'][(i+j)%3]);
   text(card,'项目 0'+(j+1),24,284,12);text(card,'在这里填写项目名称',24,325,22,true);text(card,'用一两句话说明项目的背景与方向。',24,374,13,false,'#6b665e',308);text(card,'品牌 / 包装 / 视觉 · 按需修改',24,420,11,false,'#6b665e');
  }
  const brief=frame(sheet,'案例叙事模板',54,1050,1132,330,'#e5eadf');text(brief,'01 / 项目背景',26,26,18,true);text(brief,'在这里写下项目的目标、受众与需要解决的问题。',26,76,15);text(brief,'02 / 设计思路',26,140,18,true);text(brief,'在这里补充关键词、灵感来源、图形与配色选择。',26,190,15);text(brief,'03 / 最终呈现',26,254,18,true);text(brief,'以后可替换为你的成果图、过程图或可编辑排版。',26,295,15);
  text(sheet,'一起把想法变成设计？',54,1450,30,true);box(sheet,'联系按钮',900,1450,282,60,C.yellow,5);text(sheet,'聊聊你的想法 ↗',940,1466,18,true);await connect(hit(sheet,'点击 / 联系我',900,1450,282,60),[navTo(entryPages.contact.id)]);
  categoryPages.push(cat);
 }
 // Make every folder state clickable to its matching category template.
 const componentSets=(library.children||[]).filter(n=>n.type==='COMPONENT_SET');
 for(let i=0;i<componentSets.length;i++){
  const variants=componentSets[i].children;
  for(let j=0;j<variants.length;j++){
   const rs=[{trigger:{type:'ON_CLICK'},actions:[navTo(categoryPages[i].id)]}];
   if(j<2)rs.push({trigger:{type:j===0?'MOUSE_ENTER':'MOUSE_LEAVE',delay:0,deprecatedVersion:false},actions:[{type:'NODE',destinationId:variants[j===0?1:0].id,navigation:'CHANGE_TO',transition:{type:'SMART_ANIMATE',easing:{type:'EASE_OUT'},duration:.24}}]});
   await variants[j].setReactionsAsync(rs);
  }
 }
 // WeChat now has a clickable feedback page; Figma cannot write to the clipboard.
 const wechatPage=frame(page,'微信联系 / 点击反馈',5100,1900,1440,1000,C.grey);const wxPaper=frame(wechatPage,'微信便签',405,260,630,430,'#e8eddf');shadow(wxPaper,.1,20,8);const wxTape=box(wxPaper,'胶带',260,-13,110,30,C.lavender);wxTape.rotation=-3;text(wxPaper,'微信联系',45,55,28,true);text(wxPaper,'DunDHupoy',45,130,50,true);text(wxPaper,'在真实网站可复制微信号；Figma中用于展示联系入口。',45,230,14,false,C.ink,530);text(wxPaper,'← 返回联系方式',45,330,17,true);await connect(hit(wxPaper,'返回联系方式',35,320,220,50),[navTo(entryPages.contact.id)]);
 const wxHot=hit(wechat.f,'点击 / 查看微信',0,0,wechat.f.width,wechat.f.height);await connect(wxHot,[navTo(wechatPage.id)]);
 // Add the same WeChat action to the homepage entry variants created before the hotspot.
 for(const entry of Object.values(entryPages)){
  const card=find(entry,n=>n.name==='微信联系卡片');if(card)await connect(hit(card,'点击 / 查看微信',0,0,card.width,card.height),[navTo(wechatPage.id)]);
 }
 // Native falling introduction. Matching layers animate into place with a light rebound.
 const intro0=main.clone(),intro1=main.clone();page.appendChild(intro0);page.appendChild(intro1);intro0.name='首页入场 / 元素落下起点';intro1.name='首页入场 / 落下缓冲';intro0.x=0;intro0.y=4500;intro1.x=1700;intro1.y=4500;
 for(const [stage,entry] of [[0,intro0],[1,intro1]]){
  const h=find(entry,n=>n.name==='01 / 首屏');
  for(let i=0;i<h.children.length;i++){
   const n=h.children[i];if(n.name.startsWith('点击 /'))continue;
   n.y-=stage===0?650+(i%4)*100:((i%3)+1)*12;
   n.opacity=stage===0?.05:1;
   if(stage===0&&n.type!=='TEXT')n.rotation=(i%2?1:-1)*9;
  }
 }
 await connect(intro0,[{...navTo(intro1.id),transition:{type:'SMART_ANIMATE',easing:{type:'EASE_OUT'},duration:.55}}],{type:'AFTER_TIMEOUT',timeout:.02});
 await connect(intro1,[{...navTo(main.id),transition:{type:'SMART_ANIMATE',easing:{type:'EASE_OUT_BACK'},duration:.45}}],{type:'AFTER_TIMEOUT',timeout:.02});
 // The loading sequence remains native and editable, then hands off to the falling intro.
 await connect(loadingFrames[2],[{...navTo(intro0.id),transition:{type:'DISSOLVE',easing:{type:'EASE_OUT'},duration:.2}}],{type:'AFTER_TIMEOUT',timeout:1});
 for(const loading of loadingFrames){const skip=find(loading,n=>n.name==='点击 / 直接进入首页');if(skip)await connect(skip,[navTo(intro0.id)])}
 // Refresh the long design overview after all links have been added.
 overview.remove();const updated=main.clone();overviewPage.appendChild(updated);updated.name='完整首页 / 所有内容可见可编辑';updated.resize(1440,3816);updated.x=0;updated.y=0;updated.clipsContent=false;updated.overflowDirection='NONE';updated.numberOfFixedChildren=0;
 overviewPage.selection=[updated];figma.viewport.scrollAndZoomIntoView([updated]);
 page.flowStartingPoints=[{nodeId:loadingFrames[0].id,name:'动态加载 → 落下入场 → 可交互首页'},{nodeId:main.id,name:'跳过入场 / 直接浏览首页'}];
 figma.notify('已生成可编辑首页、动态加载、落下入场和四个空白分类模板。请在02页点击演示。',{timeout:15000});figma.closePlugin();

})().catch(e=>{console.error(e);figma.notify('生成失败：'+e.message,{error:true,timeout:15000});figma.closePlugin()});
